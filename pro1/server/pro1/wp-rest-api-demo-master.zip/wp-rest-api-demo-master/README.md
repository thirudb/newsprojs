wp-rest-api-demo
================

Demo mobile app using WordPress REST API

View the tutorial here http://apppresser.com/using-wordpress-rest-api-mobile-app
